
// ==========================================
// Página do Guia - Desenvolvido por Raiol
// ==========================================
// Essa versão lê qualquer arquivo JSON localizado em assets/data.
// Basta passar o nome do arquivo ao abrir a tela (ex: 'guia_primeiros_socorros.json')

import 'dart:convert';
import 'package:flutter/material.dart';
import 'package:flutter/services.dart';
import 'package:flutter_markdown/flutter_markdown.dart';

class GuiaPage extends StatefulWidget {
  final String arquivo; // <-- nome do arquivo JSON

  const GuiaPage({super.key, required this.arquivo});

  @override
  State<GuiaPage> createState() => _GuiaPageState();
}

class _GuiaPageState extends State<GuiaPage> {
  Map<String, dynamic>? guiaData;

  @override
  void initState() {
    super.initState();
    _loadGuiaJson(); // <-- Carrega o JSON passado pelo parâmetro
  }

  Future<void> _loadGuiaJson() async {
    try {
      final String response = await rootBundle.loadString('assets/data/${widget.arquivo}');
      final data = await json.decode(response);
      setState(() {
        guiaData = data;
      });
    } catch (e) {
      // Caso o JSON não exista ou esteja com erro
      debugPrint('Erro ao carregar JSON: $e');
    }
  }

  @override
  Widget build(BuildContext context) {
    if (guiaData == null) {
      return const Scaffold(
        body: Center(child: CircularProgressIndicator()),
      );
    }

    return Scaffold(
      appBar: AppBar(
        title: Text(guiaData!['title']),
        backgroundColor: Colors.redAccent,
      ),
      body: SingleChildScrollView(
        padding: const EdgeInsets.all(16),
        child: Column(
          children: [
            // =========================
            // IMAGEM DE CAPA DO GUIA
            // =========================
            if (guiaData!['coverImage'] != null)
              ClipRRect(
                borderRadius: BorderRadius.circular(16),
                child: Image.asset(guiaData!['coverImage']),
              ),
            const SizedBox(height: 20),

            // =========================
            // CONTEÚDO EM MARKDOWN
            // =========================
            MarkdownBody(
              data: guiaData!['content'],
              styleSheet: MarkdownStyleSheet(
                p: const TextStyle(fontSize: 16, height: 1.5),
                h1: const TextStyle(fontSize: 26, fontWeight: FontWeight.bold),
                h2: const TextStyle(fontSize: 22, fontWeight: FontWeight.bold, color: Colors.redAccent),
                h3: const TextStyle(fontSize: 18, fontWeight: FontWeight.w600),
                blockquote: const TextStyle(color: Colors.grey, fontStyle: FontStyle.italic),
                listBullet: const TextStyle(fontSize: 16),
              ),
              imageBuilder: (uri, title, alt) {
                return Padding(
                  padding: const EdgeInsets.symmetric(vertical: 10),
                  child: Image.asset(uri.toString()),
                );
              },
            ),
          ],
        ),
      ),
    );
  }
}
